package com.myra.weather;

public class ServerInfo {
    public static final String base = "https://api.openweathermap.org/data/2.5/", key = "d28a3ffb04278f4e57456bbead1fffd1";
}
