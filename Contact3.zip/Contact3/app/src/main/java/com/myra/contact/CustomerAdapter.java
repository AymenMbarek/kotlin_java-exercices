package com.myra.contact;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomerAdapter extends RecyclerView.Adapter<CustomerAdapter.MyViewHolder> {
     private Context context;
     private ArrayList id , name , email , phone_number , ville;
    CustomerAdapter(Context context , ArrayList id , ArrayList name , ArrayList email , ArrayList phone_number , ArrayList ville  ){
    this.context=context;
    this.id = id;
    this.name = name;
    this.email = email;
    this.phone_number = phone_number;
    this.ville = ville;

    }
    @NonNull
    @Override
    public CustomerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent , false);
        return  new MyViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull CustomerAdapter.MyViewHolder holder, int position) {
        holder.id.setText(String.valueOf(id.get(position)));
        holder.name.setText(String.valueOf(name.get(position)));
        holder.email.setText(String.valueOf(email.get(position)));
        holder.phone_number.setText(String.valueOf(phone_number.get(position)));
        holder.ville.setText(String.valueOf(ville.get(position)));
    }



    @Override
    public int getItemCount() {
        return id.size();
    }



    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView id , name , email , phone_number , ville;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
             id= itemView.findViewById(R.id.id);
             name= itemView.findViewById(R.id.name);
             email= itemView.findViewById(R.id.email);
             phone_number= itemView.findViewById(R.id.phone_number);
             ville= itemView.findViewById(R.id.ville);
        }
    }
}
